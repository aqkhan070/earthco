import { RoutingContext } from '../../context/RoutesContext'
import { DataContext } from '../../context/AppData'
import EstimateTR from './EstimateTR'
import './Estimates.css'
import { useContext, useEffect, useState } from 'react'
import StatusCardsEst from './StatusCardsEst'

const Estimates = () => {

    const { estimates, setSingleObj, customers } = useContext(DataContext);
    const { setEstimateRoute } = useContext(RoutingContext);

    const [customer, setCustomer] = useState('Select Customer');
    const [locations, setLocations] = useState();
    const [serviceLocation, setServiceLocation] = useState('Select Customer First');
    // const [locationOptions, setLocationOptions] = useState();

    const handleCatClick = (type, id) => {
        setEstimateRoute(type);
        const updatedArr = estimates.filter((object) => {
            if (id === object.estimateID) {
                return object;
            }
        });
        setSingleObj(updatedArr);
    }
    function getLocations() {
        const locationsArr = customers.filter((item) => {
            if (customer === item.name) {
                return item.name;
            }
        })[0];
        setLocations(locationsArr);
    }
    useEffect(() => {
        setLocations(customers.filter((item) => {
            if (customer === item.name) {
                return item.name;
            }
        })[0]);
    }, [customer]);

    let locationOptions;

    if (locations) {
        locationOptions = locations.serviceLocations.map((item) => {
            return <option key={item} value={item}>{item}</option>
        })
    }


    const openModal = () => {
        getLocations();
        // console.log(locations);
    }

    const handleChangeCustomer = (e) => {
        setCustomer(e.target.value);
        getLocations();
        // console.log(locations);
    }

    // setLocationArr(updatedArr[0]);



    const saveAddEstPop = () => {

    }

    const customerOptions = customers.map((item) => {
        return <option key={item.customerId} value={item.name}>{item.name}</option>
    })


    const renderedRecords = estimates.map((object) => {
        return <EstimateTR key={object.estimateID} onClick={() => handleCatClick(`Estimate${object.estimateID}`, object.estimateID)} estimate={object} />
    });

    return (
        <div className="container-fluid">
            <div className="row">
                <StatusCardsEst drafts={28102} sent={7089} approved={4576} rejected={145} total={39912} />
                <div className="col-xl-12">
                    <div className="card">
                        <div className="card-body p-0">
                            <div className="tbl-caption">
                                <div className="row p-3 ">
                                    <div className="col-md-6">
                                        <a className="btn btn-primary btn-md" data-bs-toggle="modal" data-bs-target="#basicModal" onClick={openModal}>+ Add Estimates</a>
                                    </div>
                                    <div class="col-md-6" style={{ display: 'flex', justifyContent: 'flex-end' }}>
                                        <div className="col-md-3">
                                            <select class="default-select form-control wide" id="inlineFormCustomSelect">
                                                <option selected>All</option>
                                                <option value="1">Current Month</option>
                                                <option value="2">Previous Month</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="table-responsive active-projects style-1">
                                <table id="empoloyees-tblwrapper" className="table">
                                    <thead>
                                        <tr>
                                            <th>
                                                <div className="form-check custom-checkbox ms-2">
                                                    <input type="checkbox" className="form-check-input" id="customCheckBox2" required="" />
                                                    <label className="form-check-label" htmlFor="customCheckBox2"></label>
                                                </div>
                                            </th>
                                            <th>Estimate ID</th>
                                            <th>Customer</th>
                                            <th>Issued Date</th>
                                            <th>Approved Total</th>
                                            <th>Service Request</th>
                                            <th>QB Status</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {renderedRecords}
                                    </tbody>

                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {/* modal */}
            <div className="modal fade" id="basicModal">
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">Add Estimate</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal">
                            </button>
                        </div>
                        <form onSubmit={saveAddEstPop}>
                            <div className="modal-body">
                                <div className="basic-form">
                                    <div className="mb-3 row">
                                        <label className="col-sm-3 col-form-label">Customer</label>
                                        <div className="col-sm-9">
                                            <select class="me-sm-2 default-select form-control wide" value={customer} onChange={handleChangeCustomer} id="inlineFormCustomSelect">
                                                <option value='Select Customer'>Select Customer...</option>
                                                {customerOptions}
                                            </select>
                                        </div>
                                    </div>
                                    <div className="mb-3 row">
                                        <label className="col-sm-3 col-form-label">Quantity</label>
                                        <div className="col-sm-9">
                                            {/* hello */}
                                            <select class="me-sm-2 default-select form-control wide" value={serviceLocation} onChange={(e) => setServiceLocation(e.target.value)} id="inlineFormCustomSelect">
                                                <option value="Select Customer First">Select Customer First...</option>
                                                {locationOptions}

                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-danger light" data-bs-dismiss="modal">Close</button>
                                <button type="button" className="btn btn-primary">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    )
}

export default Estimates
